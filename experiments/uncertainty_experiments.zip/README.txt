The contents of this folder contains code to reproduce the experiments for the paper "Quantifying Uncertainty of Uplift". To run the code, follow the instructions below.
This code is provided for evaluation of the paper and will be published later in conjunction with the paper.

1. Install the requirements in the requirements.txt using pip ('pip install -r requirements.txt') using python 3.10 (other versions might work.
2. If you want to run experiments on the Criteo-uplift 2 dataset, download dataset from https://ailab.criteo.com/criteo-uplift-prediction-dataset/ and unzip into ./datasets/criteo2/
3. Run the experiments
-For tree, use as "python -m experiments.uncertainty_experiments tree dataset size max_leaf_nodes undersampling honest"
--e.g. "python -m experiments.uncertainty_experiments tree hillstrom 2000 34 False True"
-For DGP, use as "python -m experiments.uncertainty_experiments dgp dataset size"
--e.g. "python -m experiments.uncertainty_experiments dgp starbucks 2000"
--model is "dgp" or "tree" (no quotation marks)
--dataset can be "criteo2", "starbucks", or "hillstrom" (make sure to download the Criteo2 dataset to the ./datasets/ -folder)
--size the training set size and is an integer.
--max_leaf_nodes is the maximum number of leaf nodes
--undersampling is boolean and defines whether undersampling should be used (set to "True" for undersampling)
--honest is boolean and defines whether honest estimation should be used (set to "True" for honest estimation
4. Results are printed and stored in ./results/ and ./figures/
